package com.tcs.orderms.dto;

import jakarta.persistence.Column;

public class PaymentDto {

	int orderId;

	double totalAmount;

	public PaymentDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PaymentDto(int orderId, double totalAmount) {
		super();
		this.orderId = orderId;
		this.totalAmount = totalAmount;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	@Override
	public String toString() {
		return "PaymentDto [orderId=" + orderId + ", totalAmount=" + totalAmount + "]";
	}

}
