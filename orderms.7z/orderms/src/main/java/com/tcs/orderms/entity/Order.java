package com.tcs.orderms.entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="order_detail")
public class Order {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int id;
	
	@Column(name = "order_status")
	String orderStatus;
	
	@Column(name = "order_amount")
	double orderAmount;
	
	@Column(name = "order_description")
	int orderDescription;
	
	@Column(name = "order_date")
	LocalDate orderDate;

	public Order() {
		super();
	}

	
	public Order(String orderStatus, double orderAmount, int orderDescription) {
		super();
		this.orderStatus = orderStatus;
		this.orderAmount = orderAmount;
		this.orderDescription = orderDescription;
		this.orderDate = LocalDate.now();
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public int getOrderDescription() {
		return orderDescription;
	}

	public void setOrderDescription(int orderDescription) {
		this.orderDescription = orderDescription;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	
	public double getOrderAmount() {
		return orderAmount;
	}


	public void setOrderAmount(double orderAmount) {
		this.orderAmount = orderAmount;
	}


	@Override
	public String toString() {
		return "Order [id=" + id + ", orderStatus=" + orderStatus + ", orderAmount=" + orderAmount
				+ ", orderDescription=" + orderDescription + ", orderDate=" + orderDate + "]";
	}


	
}
