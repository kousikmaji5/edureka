package com.tcs.orderms.constants;

public class OrderConstant {

	public final static String PAYMENT_URL = "http://localhost:8080/payment";
}
