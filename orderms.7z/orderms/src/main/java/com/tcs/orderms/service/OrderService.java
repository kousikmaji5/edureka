package com.tcs.orderms.service;

import java.util.List;

import com.tcs.orderms.entity.Order;

public interface OrderService {
	
	List<Order> findAll();
	Order findById(int id);
	void save(Order order);
	void deleteById(int id);
	
	
}
