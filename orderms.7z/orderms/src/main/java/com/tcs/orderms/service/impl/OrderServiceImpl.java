package com.tcs.orderms.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.tcs.orderms.constants.OrderConstant;
import com.tcs.orderms.dto.PaymentDto;
import com.tcs.orderms.entity.Order;
import com.tcs.orderms.repo.OrderRepo;
import com.tcs.orderms.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService {
	
	@Autowired
	OrderRepo orderRepo;
	
	@Autowired
	RestTemplate restTemplate;

	
	@Override
	public List<Order> findAll() {
		return orderRepo.findAll();
	}

	@Override
	public Order findById(int id) {
		return orderRepo.findById(id).get();
	}

	@Override
	public void save(Order order) {
		orderRepo.save(order);
		
		PaymentDto payment = new PaymentDto(order.getId(), order.getOrderAmount());
		ResponseEntity<PaymentDto> response = restTemplate.postForEntity(OrderConstant.PAYMENT_URL, payment, PaymentDto.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			order.setOrderStatus("Completed");
			orderRepo.save(order);
		}
		
	}

	@Override
	public void deleteById(int id) {
		orderRepo.deleteById(id);
	}
	
}
