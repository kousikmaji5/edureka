package com.tcs.orderms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdermsApplicationTests {

	@Test
	void contextLoads() {
	}

}
