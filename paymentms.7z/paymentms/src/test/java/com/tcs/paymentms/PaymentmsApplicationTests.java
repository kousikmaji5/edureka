package com.tcs.paymentms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
