package com.tcs.paymentms.service;

import java.util.List;

import com.tcs.paymentms.entity.Payment;

public interface PaymentService {
	
	List<Payment> findAll();
	Payment findById(int id);
	void save(Payment payment);
	void deleteById(int id);
	
	
}
