package com.tcs.paymentms.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.paymentms.entity.Payment;
import com.tcs.paymentms.repo.PaymentRepo;
import com.tcs.paymentms.service.PaymentService;

@Service
public class PaymentServiceImpl implements PaymentService {
	
	@Autowired
	PaymentRepo paymentRepo;

	@Override
	public List<Payment> findAll() {
		return paymentRepo.findAll();
	}

	@Override
	public Payment findById(int id) {
		return paymentRepo.findById(id).get();
	}

	@Override
	public void save(Payment payment) {
		paymentRepo.save(payment);
	}

	@Override
	public void deleteById(int id) {
		paymentRepo.deleteById(id);
	}
	
}
