package com.tcs.dockerdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DockerController {
	
	@GetMapping("/")
	public String greet(Model m) {
		System.out.println("--greet--");
		return "login";
	}
	
	@PostMapping("/loginsubmit")
	public String login(Model m, @RequestParam String username, @RequestParam String password ) {
		if(username.equalsIgnoreCase("Kousik") && password.equalsIgnoreCase("Password")) {
			return "greet";
		}
		return "login";
	}
	
}
